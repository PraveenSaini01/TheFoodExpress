package com.FinalProject.OrderService.Exception;

public class OrderAlreadyExistsException extends Exception{

    public OrderAlreadyExistsException(String s) {
    }
}
