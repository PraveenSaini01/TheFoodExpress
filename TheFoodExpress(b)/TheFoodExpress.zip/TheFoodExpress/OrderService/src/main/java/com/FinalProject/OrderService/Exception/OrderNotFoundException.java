package com.FinalProject.OrderService.Exception;

public class OrderNotFoundException extends Exception{
    public OrderNotFoundException(String s) {
    }
}
