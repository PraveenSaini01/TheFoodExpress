package com.OrderNow.RestaurantService.Exception;

public class ItemNotFoundException extends Exception{
}
