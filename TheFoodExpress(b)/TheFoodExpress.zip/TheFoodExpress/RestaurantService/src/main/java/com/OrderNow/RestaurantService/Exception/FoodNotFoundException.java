package com.OrderNow.RestaurantService.Exception;

public class FoodNotFoundException extends Exception{

}
