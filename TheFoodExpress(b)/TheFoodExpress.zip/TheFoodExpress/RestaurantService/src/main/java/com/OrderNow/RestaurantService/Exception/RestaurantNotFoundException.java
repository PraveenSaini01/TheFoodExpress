package com.OrderNow.RestaurantService.Exception;

public class RestaurantNotFoundException extends Exception{

}
