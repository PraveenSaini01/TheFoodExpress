package com.OrderNow.RestaurantService.Exception;

public class RestaurantAlreadyExistsException extends Exception{
}
