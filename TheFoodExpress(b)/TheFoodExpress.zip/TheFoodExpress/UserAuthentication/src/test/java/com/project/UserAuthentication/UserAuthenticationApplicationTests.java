package com.project.UserAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(classes = UserAuthenticationApplication.class)


class UserAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
